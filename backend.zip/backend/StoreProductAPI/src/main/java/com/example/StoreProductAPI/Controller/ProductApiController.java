package com.example.StoreProductAPI.Controller;

import com.example.StoreProductAPI.Models.Product;
import com.example.StoreProductAPI.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/products")
@Api(value = "Product API", description = "Operations pertaining to products in the store")
public class ProductApiController {
    
    @Autowired
    private ProductService productService;
    
    @ApiOperation(value = "View a list of available products", response = List.class)
    @GetMapping
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @ApiOperation(value = "Get a product by ID", response = Product.class)
    @GetMapping("/{id}")
    public Product getProductById(@PathVariable int id) {
        return productService.getProductById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + id));
    }

    @ApiOperation(value = "Create a new product", response = Product.class)
    @PostMapping
    public Product createProduct(@RequestBody Product product) {
        return productService.saveProduct(product);
    }

    @ApiOperation(value = "Update an existing product", response = Product.class)
    @PutMapping("/{id}")
    public Product updateProduct(@PathVariable int id, @RequestBody Product productDetails) {
        return productService.updateProduct(id, productDetails);
    }

    @ApiOperation(value = "Delete a product")
    @DeleteMapping("/{id}")
    public void deleteProduct(@PathVariable int id) {
        productService.deleteProduct(id);
    }

    @ApiOperation(value = "Get all categories", response = List.class)
    @GetMapping("/categories")
    public List<String> getAllCategories() {
        return productService.getAllCategories();
    }

    @ApiOperation(value = "Get a single category", response = String.class)
    @GetMapping("/categories/{category}")
    public String getCategory(@PathVariable String category) {
        return productService.getCategory(category)
            .orElseThrow(() -> new ResourceNotFoundException("Category not found with name " + category));
    }

    @ApiOperation(value = "Get products by category", response = List.class)
    @GetMapping("/category/{category}")
    public List<Product> getProductsByCategory(@PathVariable String category) {
        return productService.getProductsByCategory(category);
    }

    @ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "Product not found")
    public static class ResourceNotFoundException extends RuntimeException {
        public ResourceNotFoundException(String message) {
            super(message);
        }
    }
}
