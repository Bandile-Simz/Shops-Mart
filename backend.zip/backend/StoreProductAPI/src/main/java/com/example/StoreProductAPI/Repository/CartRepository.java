package com.example.StoreProductAPI.Repository;

import com.example.StoreProductAPI.Models.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartRepository extends JpaRepository<CartItem, Long> {
}
