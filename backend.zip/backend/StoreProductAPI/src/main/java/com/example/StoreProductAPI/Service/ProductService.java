package com.example.StoreProductAPI.Service;

import com.example.StoreProductAPI.Models.Product;
import com.example.StoreProductAPI.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProductService {
    
    @Autowired
    private ProductRepository productRepository;
    
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Optional<Product> getProductById(int id) {
        return productRepository.findById(id);
    }

    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }

    public Product updateProduct(int id, Product productDetails) {
        Product product = productRepository.findById(id).orElseThrow();
        product.setTitle(productDetails.getTitle());
        product.setPrice(productDetails.getPrice());
        product.setDescription(productDetails.getDescription());
        product.setCategory(productDetails.getCategory());
        product.setImage(productDetails.getImage());
        product.setRating(productDetails.getRating());
        product.setCount(productDetails.getCount());
         product.setQuantity(productDetails.getQuantity());
        return productRepository.save(product);
    }

    public void deleteProduct(int id) {
        productRepository.deleteById(id);
    }
    
      public List<String> getAllCategories() {
        return productRepository.findAll().stream()
                .map(Product::getCategory)
                .distinct()
                .collect(Collectors.toList());
    }

    public List<Product> getProductsByCategory(String category) {
        return productRepository.findAll().stream()
                .filter(product -> category.equals(product.getCategory()))
                .collect(Collectors.toList());
    }

    public Optional<String> getCategory(String category) {
        return productRepository.findAll().stream()
                .map(Product::getCategory)
                .distinct()
                .filter(cat -> cat.equalsIgnoreCase(category))
                .findFirst();
    }
}
