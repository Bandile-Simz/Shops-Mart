package com.example.StoreProductAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StoreProductApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(StoreProductApiApplication.class, args);
        System.out.println("the main class is now running");
    }
}
