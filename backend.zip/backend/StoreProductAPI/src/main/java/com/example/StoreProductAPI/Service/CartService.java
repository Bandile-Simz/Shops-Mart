package com.example.StoreProductAPI.Service;

import com.example.StoreProductAPI.Models.CartItem;
import com.example.StoreProductAPI.Repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {
    @Autowired
    private CartRepository cartRepository;

    public List<CartItem> getAllCartItems() {
        return cartRepository.findAll();
    }

    public CartItem addCartItem(CartItem cartItem) {
        return cartRepository.save(cartItem);
    }

    public CartItem updateCartItem(Long id, CartItem updatedCartItem) {
        if (cartRepository.existsById(id)) {
            updatedCartItem.setId(id);
            return cartRepository.save(updatedCartItem);
        }
        return null;
    }

    public void deleteCartItem(Long id) {
        cartRepository.deleteById(id);
    }
}
