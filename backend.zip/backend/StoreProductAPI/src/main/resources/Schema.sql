CREATE TABLE IF NOT EXISTS product (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    price DOUBLE NOT NULL,
    description LONGTEXT,
    category VARCHAR(255),
    image LONGTEXT,
    rating DOUBLE,
    count INT,
    quantity INT
);

CREATE TABLE IF NOT EXISTS user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    email VARCHAR(255) UNIQUE,
    role VARCHAR(255) DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    productId INT,
    quantity INT NOT NULL,
    price DOUBLE NOT NULL,
    image LONGTEXT,
    title VARCHAR(200), -- Add this field to store image URL
    FOREIGN KEY (user_id) REFERENCES user(id),
    FOREIGN KEY (productId) REFERENCES product(id)
);
