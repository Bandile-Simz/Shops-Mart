package com.example.StoreProductAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreProductApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
