const API_URL = "http://localhost:8080"

// Add cache configuration
const CACHE_DURATION = 5 * 60 * 1000 // 5 minutes
const cache = new Map()

// Add retry configuration
const MAX_RETRIES = 3
const RETRY_DELAY = 1000 // 1 second

// Add timeout configuration
const TIMEOUT_DURATION = 5000 // 5 seconds

// Utility function for delay
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// Enhanced response handler
async function handleResponse(response) {
  const contentType = response.headers.get("content-type")

  if (!response.ok) {
    const error = await response.text()
    throw new Error(error || `HTTP error! status: ${response.status}`)
  }

  if (contentType && contentType.indexOf("application/json") !== -1) {
    try {
      return await response.json()
    } catch (e) {
      throw new Error("Invalid JSON response")
    }
  }

  throw new Error("Unexpected content type")
}

// Add request queue
const requestQueue = new Map()

// Enhanced fetchWithTimeout with request queuing
const fetchWithTimeout = async (url, options = {}) => {
  const queueKey = `${options.method || "GET"}-${url}`

  // Check if request is already in progress
  if (requestQueue.has(queueKey)) {
    return requestQueue.get(queueKey)
  }

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), TIMEOUT_DURATION)

  const promise = (async () => {
    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
        headers: {
          ...options.headers,
          "Cache-Control": "no-cache",
          Pragma: "no-cache",
        },
      })
      clearTimeout(timeout)
      return response
    } catch (error) {
      clearTimeout(timeout)
      if (error.name === "AbortError") {
        throw new Error("Request timeout")
      }
      throw error
    } finally {
      requestQueue.delete(queueKey)
    }
  })()

  requestQueue.set(queueKey, promise)
  return promise
}

// Add automatic retry for all API calls
const withRetry = async (fn) => {
  let lastError

  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    try {
      if (attempt > 0) {
        await delay(RETRY_DELAY * attempt)
      }
      return await fn()
    } catch (error) {
      lastError = error
      console.warn(`Attempt ${attempt + 1} failed:`, error.message)
    }
  }

  throw lastError
}

export const loginUser = async (email, password) => {
  try {
    const response = await fetch(`${API_URL}/users/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(errorText || "Failed to login")
    }

    // Get the role from response
    const role = await response.text()
    return role.trim().toLowerCase()
  } catch (error) {
    console.error("Login failed:", error)
    throw error
  }
}

export async function logoutUser() {
  try {
    const response = await fetch(`${API_URL}/users/logout`, {
      method: "POST",
      credentials: "include", // Important for cookies
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      // Instead of throwing error, we'll still log the user out on client side
      console.error(`Logout API error: ${response.status}`)
    }

    // Clear any local storage or cookies here if needed
    return true // Always return true to ensure client-side logout works
  } catch (error) {
    console.error("Logout error:", error)
    return true // Still return true to ensure client-side logout works
  }
}

export const fetchAllCartItems = async () => {
  try {
    const response = await fetch(`${API_URL}/cart`)
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return handleResponse(response)
  } catch (error) {
    console.error("Failed to fetch cart items:", error)
    throw error
  }
}

// Add cart subscribers management
const cartSubscribers = new Set();

export const subscribeToCart = (callback) => {
  cartSubscribers.add(callback);
  return () => cartSubscribers.delete(callback);
};

export const notifyCartSubscribers = () => {
  cartSubscribers.forEach(callback => callback());
};

export const addCartItem = async (item) => {
  try {
    const response = await fetch(`${API_URL}/cart`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(item),
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    const result = await handleResponse(response)
    notifyCartSubscribers(); // Notify subscribers after successful addition
    return result;
  } catch (error) {
    console.error("Failed to add cart item:", error)
    throw error
  }
}

export const updateCartItem = async (itemId, item) => {
  try {
    const response = await fetch(`${API_URL}/cart/${itemId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(item),
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return handleResponse(response)
  } catch (error) {
    console.error("Failed to update cart item:", error)
    throw error
  }
}

export const deleteCartItem = async (itemId) => {
  try {
    const response = await fetch(`${API_URL}/cart/${itemId}`, {
      method: "DELETE",
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    await response.text()
    notifyCartSubscribers(); // Notify subscribers after successful deletion
  } catch (error) {
    console.error("Failed to delete cart item:", error)
    throw error
  }
}

// Enhanced fetchAllProducts with caching and retries
export const fetchAllProducts = async () => {
  const cacheKey = "all-products"

  // Check cache first
  const cachedData = cache.get(cacheKey)
  if (cachedData && Date.now() - cachedData.timestamp < CACHE_DURATION) {
    return cachedData.data
  }

  let lastError

  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    try {
      if (attempt > 0) {
        await delay(RETRY_DELAY * attempt)
      }

      const response = await fetchWithTimeout(`${API_URL}/products`)
      const data = await handleResponse(response)

      // Validate data structure
      if (!Array.isArray(data)) {
        throw new Error("Invalid data format received")
      }

      // Update cache
      cache.set(cacheKey, {
        data,
        timestamp: Date.now(),
      })

      return data
    } catch (error) {
      lastError = error
      console.warn(`Attempt ${attempt + 1} failed:`, error.message)
    }
  }

  throw new Error(`Failed to fetch products after ${MAX_RETRIES} attempts: ${lastError.message}`)
}

// Enhanced fetchProductById with caching and retries
export const fetchProductById = async (id) => {
  const cacheKey = `product-${id}`

  // Check cache first
  const cachedData = cache.get(cacheKey)
  if (cachedData && Date.now() - cachedData.timestamp < CACHE_DURATION) {
    return cachedData.data
  }

  let lastError

  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    try {
      if (attempt > 0) {
        await delay(RETRY_DELAY * attempt)
      }

      const response = await fetchWithTimeout(`${API_URL}/products/${id}`)
      const data = await handleResponse(response)

      // Validate data structure
      if (!data || typeof data !== "object") {
        throw new Error("Invalid data format received")
      }

      // Update cache
      cache.set(cacheKey, {
        data,
        timestamp: Date.now(),
      })

      return data
    } catch (error) {
      lastError = error
      console.warn(`Attempt ${attempt + 1} failed:`, error.message)
    }
  }

  throw new Error(`Failed to fetch product ${id} after ${MAX_RETRIES} attempts: ${lastError.message}`)
}

// Cache clearing function
export const clearProductCache = () => {
  cache.clear()
}

export const addProduct = async (product) => {
  try {
    const response = await fetch(`${API_URL}/products`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(product),
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return handleResponse(response)
  } catch (error) {
    console.error("Failed to add product:", error)
    throw error
  }
}

export const updateProduct = async (id, product) => {
  try {
    const response = await fetch(`${API_URL}/products/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(product),
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return handleResponse(response)
  } catch (error) {
    console.error("Failed to update product:", error)
    throw error
  }
}

export const deleteProduct = async (id) => {
  try {
    const response = await fetch(`${API_URL}/products/${id}`, {
      method: "DELETE",
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    await response.text() // Consume the response body
  } catch (error) {
    console.error("Failed to delete product:", error)
    throw error
  }
}

export const fetchAllUsers = async () => {
  try {
    const response = await fetch(`${API_URL}/users`)
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return handleResponse(response)
  } catch (error) {
    console.error("Failed to fetch users:", error)
    throw error
  }
}

export const deleteUser = async (userId) => {
  try {
    const response = await fetch(`${API_URL}/users/${userId}`, {
      method: "DELETE",
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    await response.text() // Consume the response body
  } catch (error) {
    console.error("Failed to delete user:", error)
    throw error
  }
}

// Update the fetchWishlist function with retries and better error handling
export const fetchWishlist = async (email) => {
  return withRetry(async () => {
    try {
      const response = await fetchWithTimeout(`${API_URL}/wishlist/${email}`)
      const data = await handleResponse(response)
      return Array.isArray(data) ? data : []
    } catch (error) {
      console.error("Failed to fetch wishlist:", error)
      return []
    }
  })
}

export const addToWishlist = async (email, item) => {
  try {
    const response = await fetchWithTimeout(`${API_URL}/wishlist/${email}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(item),
    })
    return await handleResponse(response)
  } catch (error) {
    console.error("Failed to add to wishlist:", error)
    throw error
  }
}

export const removeFromWishlist = async (email, productId) => {
  try {
    const response = await fetchWithTimeout(`${API_URL}/wishlist/${email}/${productId}`, {
      method: "DELETE",
    })
    if (!response.ok) {
      throw new Error("Failed to remove from wishlist")
    }
    return true
  } catch (error) {
    console.error("Failed to remove from wishlist:", error)
    throw error
  }
}

export const searchProducts = async (keyword) => {
  try {
    const response = await fetchWithTimeout(`${API_URL}/products/search?keyword=${encodeURIComponent(keyword)}`)
    const data = await handleResponse(response)

    // Validate data structure
    if (!Array.isArray(data)) {
      throw new Error("Invalid search results format")
    }

    return data
  } catch (error) {
    console.error("Search failed:", error)
    throw error
  }
}

export const fetchUserProfile = async (email) => {
  try {
    const response = await fetchWithTimeout(`${API_URL}/users/${email}`)
    return await handleResponse(response)
  } catch (error) {
    console.error("Failed to fetch user profile:", error)
    throw error
  }
}

export const updateUserProfile = async (email, data) => {
  try {
    const response = await fetchWithTimeout(`${API_URL}/users/${email}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
    return await handleResponse(response)
  } catch (error) {
    console.error("Failed to update user profile:", error)
    throw error
  }
}

