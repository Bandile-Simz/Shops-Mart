"use client"

import { useState, useEffect } from "react"
import { fetchAllProducts, searchProducts } from "../../services/api-service"
import ProductGrid from "../../components/ProductGrid"
import SearchBar from "../../components/SearchBar"
import CategoryFilter from "../../components/CategoryFilter"
import LoadingSpinner from "../../components/LoadingSpinner"

export default function ProductsPage() {
  const [products, setProducts] = useState([])
  const [filteredProducts, setFilteredProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)
  const [currentPage, setCurrentPage] = useState(1)
  const productsPerPage = 8

  useEffect(() => {
    const loadProducts = async () => {
      try {
        setIsLoading(true)
        const data = await fetchAllProducts()
        setProducts(data)
        setFilteredProducts(data)

        // Extract unique categories
        const uniqueCategories = [...new Set(data.map((product) => product.category))]
        setCategories(uniqueCategories)
      } catch (err) {
        console.error("Failed to fetch products:", err)
        setError("Failed to load products. Please try again later.")
      } finally {
        setIsLoading(false)
      }
    }

    loadProducts()
  }, [])

  const handleSearch = async (keyword) => {
    if (!keyword.trim()) {
      setFilteredProducts(products)
      return
    }

    try {
      setIsLoading(true)
      const results = await searchProducts(keyword)
      setFilteredProducts(results)
    } catch (err) {
      console.error("Search failed:", err)
      setError("Search failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleCategoryChange = (category) => {
    setSelectedCategory(category)

    if (category === "all") {
      setFilteredProducts(products)
    } else {
      const filtered = products.filter((product) => product.category === category)
      setFilteredProducts(filtered)
    }
  }

  // Get current products
  const indexOfLastProduct = currentPage * productsPerPage
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage
  const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct)
  const totalPages = Math.ceil(filteredProducts.length / productsPerPage)

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <div className="min-h-screen bg-indigo-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-indigo-900">Our Products</h1>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <SearchBar onSearch={handleSearch} />
          <CategoryFilter
            categories={categories}
            selectedCategory={selectedCategory}
            onCategoryChange={handleCategoryChange}
          />
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <LoadingSpinner />
          </div>
        ) : error ? (
          <div className="text-center text-red-500 p-4 bg-red-50 rounded-md">{error}</div>
        ) : (
          <>
            {filteredProducts.length > 0 ? (
              <>
                <ProductGrid products={currentProducts} />
                
                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex justify-center mt-8 space-x-2">
                    <button
                      onClick={() => handlePageChange(currentPage - 1)}
                      disabled={currentPage === 1}
                      className="px-4 py-2 rounded-md border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                    >
                      Previous
                    </button>
                    
                    {[...Array(totalPages)].map((_, index) => (
                      <button
                        key={index + 1}
                        onClick={() => handlePageChange(index + 1)}
                        className={`px-4 py-2 rounded-md border ${
                          currentPage === index + 1
                            ? 'bg-primary text-white border-primary'
                            : 'border-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        {index + 1}
                      </button>
                    ))}
                    
                    <button
                      onClick={() => handlePageChange(currentPage + 1)}
                      disabled={currentPage === totalPages}
                      className="px-4 py-2 rounded-md border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                    >
                      Next
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center p-8 bg-white rounded-md shadow">
                No products found. Try a different search or category.
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

