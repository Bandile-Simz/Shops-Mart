"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { fetchProductById, addCartItem, addToWishlist } from "../../../services/api-service"
import { Heart, ShoppingCart, ArrowLeft, Minus, Plus, Star } from "lucide-react"
import LoadingSpinner from "../../../components/LoadingSpinner"

export default function ProductDetailPage({ params }) {
  const router = useRouter()
  const { id } = params

  const [product, setProduct] = useState(null)
  const [quantity, setQuantity] = useState(1)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)
  const [activeImage, setActiveImage] = useState(0)
  const [addingToCart, setAddingToCart] = useState(false)
  const [addingToWishlist, setAddingToWishlist] = useState(false)

  useEffect(() => {
    const loadProduct = async () => {
      try {
        setIsLoading(true)
        const data = await fetchProductById(id)
        setProduct(data)
      } catch (err) {
        console.error("Failed to fetch product:", err)
        setError("Failed to load product details. Please try again later.")
      } finally {
        setIsLoading(false)
      }
    }

    if (id) {
      loadProduct()
    }
  }, [id])

  const handleQuantityChange = (value) => {
    const newQuantity = Math.max(1, Math.min(99, value))
    setQuantity(newQuantity)
  }

  const handleAddToCart = async () => {
    if (!product) return

    try {
      setAddingToCart(true)
      await addCartItem({
        productId: product.id,
        quantity,
        price: product.price,
        name: product.name,
        image: product.images?.[0] || product.image,
        description: product.description
      })
      alert("Product added to cart!")
    } catch (error) {
      console.error("Failed to add to cart:", error)
      alert("Failed to add to cart. Please try again.")
    } finally {
      setAddingToCart(false)
    }
  }

  const handleAddToWishlist = async () => {
    if (!product) return

    try {
      setAddingToWishlist(true)
      // Assuming we have the user's email from authentication
      const userEmail = localStorage.getItem("userEmail")
      if (!userEmail) {
        router.push("/login")
        return
      }

      await addToWishlist(userEmail, { productId: product.id })
      alert("Product added to wishlist!")
    } catch (error) {
      console.error("Failed to add to wishlist:", error)
      alert("Failed to add to wishlist. Please try again.")
    } finally {
      setAddingToWishlist(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <LoadingSpinner />
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center text-red-500 p-4 bg-red-50 rounded-md">{error}</div>
        <div className="mt-4 text-center">
          <button
            onClick={() => router.push("/")}
            className="inline-flex items-center text-primary hover:text-primary-dark"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to products
          </button>
        </div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center p-4 bg-gray-100 rounded-md">Product not found</div>
        <div className="mt-4 text-center">
          <button
            onClick={() => router.push("/")}
            className="inline-flex items-center text-primary hover:text-primary-dark"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to products
          </button>
        </div>
      </div>
    )
  }

  // Mock data for product images (in a real app, this would come from the API)
  const productImages = [
    product.images?.[0] || product.image || "/placeholder.svg?height=600&width=600",
    product.images?.[1] || "/placeholder.svg?height=600&width=600&text=Image+2",
    product.images?.[2] || "/placeholder.svg?height=600&width=600&text=Image+3",
    product.images?.[3] || "/placeholder.svg?height=600&width=600&text=Image+4",
  ]

  // Generate star rating display
  const renderRating = () => {
    const stars = []
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Star
          key={i}
          className={`h-5 w-5 ${i <= product.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
        />,
      )
    }
    return stars
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <button
        onClick={() => router.push("/")}
        className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to products
      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="aspect-w-1 aspect-h-1 bg-gray-100 rounded-lg overflow-hidden">
            <img
              src={productImages[activeImage] || "/placeholder.svg"}
              alt={product.name}
              className="w-full h-full object-center object-cover"
            />
          </div>

          <div className="grid grid-cols-4 gap-2">
            {productImages.map((image, index) => (
              <button
                key={index}
                onClick={() => setActiveImage(index)}
                className={`aspect-w-1 aspect-h-1 rounded-md overflow-hidden border-2 ${
                  activeImage === index ? "border-primary" : "border-transparent"
                }`}
              >
                <img
                  src={image || "/placeholder.svg"}
                  alt={`${product.name} thumbnail ${index + 1}`}
                  className="w-full h-full object-center object-cover"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{product.name}</h1>
            <div className="mt-2 flex items-center">
              <div className="flex mr-2">{renderRating()}</div>
              <span className="text-gray-500 text-sm">({product.reviews || 0} reviews)</span>
            </div>
          </div>

          <div className="text-2xl font-bold text-gray-900">${product.price.toFixed(2)}</div>

          <div>
            <h3 className="text-lg font-medium text-gray-900">Description</h3>
            <div className="mt-2 text-gray-600">{product.description}</div>
          </div>

          <div className="border-t border-b border-gray-200 py-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-900 font-medium">Quantity</span>
              <div className="flex items-center border border-gray-300 rounded-md">
                <button
                  type="button"
                  onClick={() => handleQuantityChange(quantity - 1)}
                  disabled={quantity <= 1}
                  className="p-2 text-gray-500 hover:text-gray-700 disabled:opacity-50"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <input
                  type="number"
                  min="1"
                  max="99"
                  value={quantity}
                  onChange={(e) => handleQuantityChange(Number.parseInt(e.target.value) || 1)}
                  className="w-12 text-center border-0 focus:ring-0"
                />
                <button
                  type="button"
                  onClick={() => handleQuantityChange(quantity + 1)}
                  className="p-2 text-gray-500 hover:text-gray-700"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button
              type="button"
              onClick={handleAddToCart}
              disabled={addingToCart}
              className="flex-1 bg-primary hover:bg-primary-dark text-white font-bold py-3 px-6 rounded-md flex items-center justify-center"
            >
              {addingToCart ? (
                <div className="h-5 w-5 border-t-2 border-white border-solid rounded-full animate-spin mr-2"></div>
              ) : (
                <ShoppingCart className="h-5 w-5 mr-2" />
              )}
              Add to Cart
            </button>

            <button
              type="button"
              onClick={handleAddToWishlist}
              disabled={addingToWishlist}
              className="flex-1 bg-white border border-gray-300 text-gray-700 font-bold py-3 px-6 rounded-md flex items-center justify-center hover:bg-gray-50"
            >
              {addingToWishlist ? (
                <div className="h-5 w-5 border-t-2 border-gray-700 border-solid rounded-full animate-spin mr-2"></div>
              ) : (
                <Heart className="h-5 w-5 mr-2" />
              )}
              Add to Wishlist
            </button>
          </div>

          <div className="bg-gray-50 p-4 rounded-md">
            <div className="flex items-center mb-2">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
              <span className="text-green-600 font-medium">In Stock</span>
            </div>
            <p className="text-sm text-gray-600">Free shipping on orders over $50</p>
          </div>
        </div>
      </div>
    </div>
  )
}

