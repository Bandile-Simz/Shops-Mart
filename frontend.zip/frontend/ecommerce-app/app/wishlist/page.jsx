"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { fetchWishlist, removeFromWishlist, addCartItem } from "../../services/api-service"
import { Trash2, ShoppingBag, ShoppingCart } from "lucide-react"
import LoadingSpinner from "../../components/LoadingSpinner"

export default function WishlistPage() {
  const router = useRouter()
  const [wishlistItems, setWishlistItems] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)
  const [actionInProgress, setActionInProgress] = useState(null)

  useEffect(() => {
    const loadWishlist = async () => {
      try {
        setIsLoading(true)
        const userEmail = localStorage.getItem("userEmail")
        if (!userEmail) {
          router.push("/login")
          return
        }

        const data = await fetchWishlist(userEmail)
        setWishlistItems(data)
      } catch (err) {
        console.error("Failed to fetch wishlist:", err)
        setError("Failed to load your wishlist. Please try again later.")
      } finally {
        setIsLoading(false)
      }
    }

    loadWishlist()
  }, [router])

  const handleRemoveFromWishlist = async (productId) => {
    try {
      setActionInProgress(productId)
      const userEmail = localStorage.getItem("userEmail")
      await removeFromWishlist(userEmail, productId)
      setWishlistItems(wishlistItems.filter(item => item.id !== productId))
    } catch (error) {
      console.error("Failed to remove from wishlist:", error)
      alert("Failed to remove item. Please try again.")
    } finally {
      setActionInProgress(null)
    }
  }

  const handleMoveToCart = async (product) => {
    try {
      setActionInProgress(product.id)
      await addCartItem({
        productId: product.id,
        quantity: 1,
        price: product.price
      })
      await handleRemoveFromWishlist(product.id)
      alert("Product moved to cart!")
    } catch (error) {
      console.error("Failed to move to cart:", error)
      alert("Failed to move item to cart. Please try again.")
    } finally {
      setActionInProgress(null)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner />
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center text-red-500 p-4 bg-red-50 rounded-md">{error}</div>
      </div>
    )
  }

  if (wishlistItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="text-center">
          <ShoppingBag className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h2 className="text-2xl font-bold mb-2">Your wishlist is empty</h2>
          <p className="text-gray-600 mb-6">Start adding some items to your wishlist!</p>
          <button
            onClick={() => router.push("/products")}
            className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-md"
          >
            Browse Products
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">My Wishlist ({wishlistItems.length} items)</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {wishlistItems.map((item) => (
          <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="relative h-48">
              <img
                src={item.images?.[0] || item.image || "/placeholder.svg"}
                alt={item.name}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="p-4">
              <h3 className="text-lg font-semibold mb-2 text-gray-900">{item.name}</h3>
              <p className="text-gray-600 text-sm mb-4 line-clamp-2">{item.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold text-gray-900">${item.price?.toFixed(2)}</span>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleMoveToCart(item)}
                    disabled={actionInProgress === item.id}
                    className="p-2 text-primary hover:text-primary-dark"
                    title="Move to Cart"
                  >
                    {actionInProgress === item.id ? (
                      <div className="h-5 w-5 border-t-2 border-primary border-solid rounded-full animate-spin"></div>
                    ) : (
                      <ShoppingCart className="h-5 w-5" />
                    )}
                  </button>
                  <button
                    onClick={() => handleRemoveFromWishlist(item.id)}
                    disabled={actionInProgress === item.id}
                    className="p-2 text-red-500 hover:text-red-700"
                    title="Remove from Wishlist"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
