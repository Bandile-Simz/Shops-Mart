"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import AdminLayout from "../../../components/admin/AdminLayout"
import { BarChart, Users, Package, DollarSign, ShoppingCart, TrendingUp } from "lucide-react"
import { fetchAllUsers, fetchAllProducts } from "../../../services/api-service"
import LoadingSpinner from "../../../components/LoadingSpinner"

export default function AdminDashboard() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalProducts: 0,
    totalOrders: 0,
    totalRevenue: 0,
  })

  useEffect(() => {
    // Check if user is admin
    const userRole = localStorage.getItem("userRole")
    if (userRole !== "admin") {
      router.push("/login")
      return
    }

    const loadDashboardData = async () => {
      try {
        setIsLoading(true)

        // Fetch data in parallel
        const [users, products] = await Promise.all([fetchAllUsers(), fetchAllProducts()])

        // Calculate stats
        setStats({
          totalUsers: users.length,
          totalProducts: products.length,
          totalOrders: 156, // Mock data - would come from API in real app
          totalRevenue: 12589.99, // Mock data - would come from API in real app
        })
      } catch (err) {
        console.error("Failed to load dashboard data:", err)
        setError("Failed to load dashboard data. Please try again later.")
      } finally {
        setIsLoading(false)
      }
    }

    loadDashboardData()
  }, [router])

  // Mock data for charts
  const recentOrders = [
    { id: "ORD-1234", customer: "John Doe", date: "2023-06-15", total: 129.99, status: "Delivered" },
    { id: "ORD-1235", customer: "Jane Smith", date: "2023-06-14", total: 89.99, status: "Processing" },
    { id: "ORD-1236", customer: "Robert Johnson", date: "2023-06-14", total: 199.99, status: "Shipped" },
    { id: "ORD-1237", customer: "Emily Davis", date: "2023-06-13", total: 59.99, status: "Delivered" },
    { id: "ORD-1238", customer: "Michael Brown", date: "2023-06-12", total: 149.99, status: "Processing" },
  ]

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex justify-center items-center h-64">
          <LoadingSpinner />
        </div>
      </AdminLayout>
    )
  }

  if (error) {
    return (
      <AdminLayout>
        <div className="text-center text-red-500 p-4 bg-red-50 rounded-md">{error}</div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-6">Dashboard</h1>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-blue-100 text-blue-600">
                <Users className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Total Users</h2>
                <p className="text-2xl font-semibold">{stats.totalUsers}</p>
              </div>
            </div>
            <div className="mt-4 text-xs text-green-500 flex items-center">
              <TrendingUp className="h-3 w-3 mr-1" />
              <span>12% increase this month</span>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-100 text-green-600">
                <Package className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Total Products</h2>
                <p className="text-2xl font-semibold">{stats.totalProducts}</p>
              </div>
            </div>
            <div className="mt-4 text-xs text-green-500 flex items-center">
              <TrendingUp className="h-3 w-3 mr-1" />
              <span>5% increase this month</span>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-purple-100 text-purple-600">
                <ShoppingCart className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Total Orders</h2>
                <p className="text-2xl font-semibold">{stats.totalOrders}</p>
              </div>
            </div>
            <div className="mt-4 text-xs text-green-500 flex items-center">
              <TrendingUp className="h-3 w-3 mr-1" />
              <span>18% increase this month</span>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-yellow-100 text-yellow-600">
                <DollarSign className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Total Revenue</h2>
                <p className="text-2xl font-semibold">${stats.totalRevenue.toLocaleString()}</p>
              </div>
            </div>
            <div className="mt-4 text-xs text-green-500 flex items-center">
              <TrendingUp className="h-3 w-3 mr-1" />
              <span>24% increase this month</span>
            </div>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold mb-4">Sales Overview</h2>
            <div className="flex items-center justify-center h-64 bg-gray-50 rounded-md">
              <BarChart className="h-12 w-12 text-gray-400" />
              <span className="ml-2 text-gray-500">Sales chart will be displayed here</span>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold mb-4">Top Selling Products</h2>
            <div className="flex items-center justify-center h-64 bg-gray-50 rounded-md">
              <BarChart className="h-12 w-12 text-gray-400" />
              <span className="ml-2 text-gray-500">Products chart will be displayed here</span>
            </div>
          </div>
        </div>

        {/* Recent Orders */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Recent Orders</h2>
            <button
              onClick={() => router.push("/admin/orders")}
              className="text-sm text-primary hover:text-primary-dark"
            >
              View All
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Order ID
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Customer
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Date
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Total
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {recentOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-primary">{order.id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{order.customer}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{order.date}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.total}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                        ${
                          order.status === "Delivered"
                            ? "bg-green-100 text-green-800"
                            : order.status === "Shipped"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {order.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}

