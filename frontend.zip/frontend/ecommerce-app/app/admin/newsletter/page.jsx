"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import AdminLayout from "../../../components/admin/AdminLayout"
import { Mail, Send, Trash2, Filter, Search, Download, Upload } from "lucide-react"
import LoadingSpinner from "../../../components/LoadingSpinner"

export default function AdminNewsletter() {
  const router = useRouter();
  const [subscribers, setSubscribers] = useState([]);
  const [filteredSubscribers, setFilteredSubscribers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [showComposeModal, setShowComposeModal] = useState(false);
  const [newsletterForm, setNewsletterForm] = useState({
    subject: '',
    content: '',
    sendToAll: true,
  });
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    // Check if user is admin
    const userRole = localStorage.getItem('userRole');
    if (userRole !== 'admin') {
      router.push('/login');
      return;
    }

    // Mock data for subscribers
    const mockSubscribers = [
      { id: 1, email: 'john.doe@example.com', status: 'active', dateSubscribed: '2023-01-15' },
      { id: 2, email: 'jane.smith@example.com', status: 'active', dateSubscribed: '2023-02-20' },
      { id: 3, email: 'robert.johnson@example.com', status: 'inactive', dateSubscribed: '2023-03-10' },
      { id: 4, email: 'emily.davis@example.com', status: 'active', dateSubscribed: '2023-04-05' },
      { id: 5, email: 'michael.brown@example.com', status: 'active', dateSubscribed: '2023-05-12' },
      { id: 6, email: 'sarah.wilson@example.com', status: 'inactive', dateSubscribed: '2023-06-18' },
      { id: 7, email: 'david.taylor@example.com', status: 'active', dateSubscribed: '2023-07-22' },
      { id: 8, email: 'olivia.thomas@example.com', status: 'active', dateSubscribed: '2023-08-30' },
      { id: 9, email: 'james.roberts@example.com', status: 'inactive', dateSubscribed: '2023-09-14' },
      { id: 10, email: 'sophia.walker@example.com', status: 'active', dateSubscribed: '2023-10-25' },
    ];

    // Simulate API call
    setTimeout(() => {
      setSubscribers(mockSubscribers);
      setFilteredSubscribers(mockSubscribers);
      setIsLoading(false);
    }, 1000);
  }, [router]);

  useEffect(() => {
    // Filter subscribers based on search query and selected status
    let result = subscribers;
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(subscriber => 
        subscriber.email.toLowerCase().includes(query)
      );
    }
    
    if (selectedStatus !== 'all') {
      result = result.filter(subscriber => subscriber.status === selectedStatus);
    }
    
    setFilteredSubscribers(result);
  }, [searchQuery, selectedStatus, subscribers]);

  const handleSendNewsletter = async (e) => {
    e.preventDefault();
    
    if (!newsletterForm.subject || !newsletterForm.content) {
      alert('Please fill in all required fields');
      return;
    }
    
    try {
      setIsSending(true);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Success message
      alert('Newsletter sent successfully!');
      setShowComposeModal(false);
      setNewsletterForm({
        subject: '',
        content: '',
        sendToAll: true,
      });
    } catch (error) {
      console.error('Failed to send newsletter:', error);
      alert('Failed to send newsletter. Please try again.');
    } finally {
      setIsSending(false);
    }
  };

  const handleDeleteSubscriber = async (id) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Update local state
      setSubscribers(subscribers.filter(subscriber => subscriber.id !== id));
      setFilteredSubscribers(filteredSubscribers.filter(subscriber => subscriber.id !== id));
      
      // Success message
      alert('Subscriber removed successfully!');
    } catch (error) {
      console.error('Failed to delete subscriber:', error);
      alert('Failed to delete subscriber. Please try again.');
    }
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex justify-center items-center h-64">
          <LoadingSpinner />
        </div>
      </AdminLayout>
    );
  }

  if (error) {
    return (
      <AdminLayout>
        <div className="p-6">
          <div className="text-center text-red-500 p-4 bg-red-50 rounded-md">
            {error}
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <h1 className="text-2xl font-bold mb-4 md:mb-0">Newsletter Management</h1>
          <div className="flex flex-col sm:flex-row gap-2">
            <button
              onClick={() => setShowComposeModal(true)}
              className="flex items-center bg-primary text-white px-4 py-2 rounded-md hover:bg-primary-dark transition-colors"
            >
              <Send className="h-5 w-5 mr-2" />
              Compose Newsletter
            </button>
            <button
              className="flex items-center bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 transition-colors"
            >
              <Upload className="h-5 w-5 mr-2" />
              Import Subscribers
            </button>
            <button
              className="flex items-center bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 transition-colors"
            >
              <Download className="h-5 w-5 mr-2" />
              Export Subscribers
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-blue-100 text-blue-600">
                <Mail className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Total Subscribers</h2>
                <p className="text-2xl font-semibold">{subscribers.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-100 text-green-600">
                <Mail className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Active Subscribers</h2>
                <p className="text-2xl font-semibold">
                  {subscribers.filter(s => s.status === 'active').length}
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-yellow-100 text-yellow-600">
                <Mail className="h-6 w-6" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Inactive Subscribers</h2>
                <p className="text-2xl font-semibold">
                  {subscribers.filter(s => s.status === 'inactive').length}
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-4 border-b">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Search subscribers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              </div>
              
              <div className="flex items-center">
                <Filter className="h-5 w-5 text-gray-400 mr-2" />
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                >
                  <option value="all">All Status</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date Subscribed
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredSubscribers.map((subscriber) => (
                  <tr key={subscriber.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{subscriber.email}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        subscriber.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {subscriber.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {subscriber.dateSubscribed}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleDeleteSubscriber(subscriber.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        <Trash2 className="h-5 w-5" />
                        <span className="sr-only">Delete</span>
                      </button>
                    </td>
                  </tr>
                ))}
                
                {filteredSubscribers.length === 0 && (
                  <tr>
                    <td colSpan="4" className="px-6 py-4 text-center text-gray-500">
                      No subscribers found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      {/* Compose Newsletter Modal */}
      {showComposeModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <form onSubmit={handleSendNewsletter}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <div className="sm:flex sm:items-start">
                    <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 sm:mx-0 sm:h-10 sm:w-10">
                      <Send className="h-6 w-6 text-blue-600" />
                    </div>
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">Compose Newsletter</h3>
                      <div className="mt-4 space-y-4">
                        <div>
                          <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                            Subject <span className="text-red-500">*</span>
                          </label>
                          <input
                            type="text"
                            id="subject"
                            value={newsletterForm.subject}
                            onChange={(e) => setNewsletterForm({ ...newsletterForm, subject: e.target.value })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                            required
                          />
                        </div>
                        
                        <div>
                          <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-1">
                            Content <span className="text-red-500">*</span>
                          </label>
                          <textarea
                            id="content"
                            rows="6"
                            value={newsletterForm.content}
                            onChange={(e) => setNewsletterForm({ ...newsletterForm, content: e.target.value })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary focus:border-primary"
                            required
                          />
                        </div>
                        
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="sendToAll"
                            checked={newsletterForm.sendToAll}
                            onChange={(e) => setNewsletterForm({ ...newsletterForm, sendToAll: e.target.checked })}
                            className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                          />
                          <label htmlFor="sendToAll" className="ml-2 block text-sm text-gray-900">
                            Send to all subscribers
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    disabled={isSending}
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-primary text-base font-medium text-white hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    {isSending ? 'Sending...' : 'Send Newsletter'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowComposeModal(false)}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}

