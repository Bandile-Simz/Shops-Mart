"use client"
import { useRouter } from "next/navigation"
import AdminLayout from "../../../../components/admin/AdminLayout"
import AddProductForm from "../../../../components/admin/AddProductForm"
import { addProduct } from "../../../../services/api-service"
import { NotificationProvider } from "../../../../context/NotificationContext"

export default function AddProductPage() {
  const router = useRouter()

  const handleAddProduct = async (productData) => {
    await addProduct(productData)
    router.push("/admin/products")
  }

  return (
    <AdminLayout>
      <NotificationProvider>
        <div className="p-6">
          <AddProductForm onAddProduct={handleAddProduct} />
        </div>
      </NotificationProvider>
    </AdminLayout>
  )
}

