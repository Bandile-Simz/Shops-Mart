"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { fetchAllCartItems, updateCartItem, deleteCartItem } from "../../services/api-service"
import { Trash2, ShoppingBag, ArrowRight, Minus, Plus } from "lucide-react"
import LoadingSpinner from "../../components/LoadingSpinner"

export default function CartPage() {
  const router = useRouter()
  const [cartItems, setCartItems] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)
  const [updatingItem, setUpdatingItem] = useState(null)
  const [deletingItem, setDeletingItem] = useState(null)

  useEffect(() => {
    const loadCartItems = async () => {
      try {
        setIsLoading(true)
        const data = await fetchAllCartItems()
        setCartItems(data)
      } catch (err) {
        console.error("Failed to fetch cart items:", err)
        setError("Failed to load your cart. Please try again later.")
      } finally {
        setIsLoading(false)
      }
    }

    loadCartItems()
  }, [])

  const handleQuantityChange = async (itemId, newQuantity) => {
    if (newQuantity < 1) return

    try {
      setUpdatingItem(itemId)
      const updatedItem = cartItems.find((item) => item.id === itemId)
      if (!updatedItem) return

      const updated = { ...updatedItem, quantity: newQuantity }
      await updateCartItem(itemId, updated)

      // Update local state
      setCartItems(cartItems.map((item) => (item.id === itemId ? { ...item, quantity: newQuantity } : item)))
    } catch (err) {
      console.error("Failed to update quantity:", err)
      alert("Failed to update quantity. Please try again.")
    } finally {
      setUpdatingItem(null)
    }
  }

  const handleRemoveItem = async (itemId) => {
    try {
      setDeletingItem(itemId)
      await deleteCartItem(itemId)

      // Update local state
      setCartItems(cartItems.filter((item) => item.id !== itemId))
    } catch (err) {
      console.error("Failed to remove item:", err)
      alert("Failed to remove item. Please try again.")
    } finally {
      setDeletingItem(null)
    }
  }

  const calculateSubtotal = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const calculateTax = () => {
    return calculateSubtotal() * 0.08 // 8% tax
  }

  const calculateShipping = () => {
    const subtotal = calculateSubtotal()
    return subtotal > 50 ? 0 : 5.99 // Free shipping over $50
  }

  const calculateTotal = () => {
    return calculateSubtotal() + calculateTax() + calculateShipping()
  }

  const calculateTotalItems = () => {
    return cartItems.reduce((total, item) => total + item.quantity, 0)
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner />
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center text-red-500 p-4 bg-red-50 rounded-md">{error}</div>
        <div className="mt-4 text-center">
          <button
            onClick={() => router.push("/")}
            className="inline-flex items-center text-primary hover:text-primary-dark"
          >
            Back to shopping
          </button>
        </div>
      </div>
    )
  }

  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="text-center">
          <ShoppingBag className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
          <p className="text-gray-600 mb-6">Looks like you haven't added any products to your cart yet.</p>
          <button
            onClick={() => router.push("/")}
            className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-md"
          >
            Start Shopping
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Your Shopping Cart</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold">
                Cart Items ({calculateTotalItems()} {calculateTotalItems() === 1 ? 'item' : 'items'})
              </h2>
            </div>

            <ul className="divide-y divide-gray-200">
              {cartItems.map((item) => (
                <li key={item.id} className="p-4 flex flex-col sm:flex-row sm:items-center">
                  <div className="flex-shrink-0 w-24 h-24 bg-gray-100 rounded-md overflow-hidden">
                    <img
                      src={item.images?.[0] || item.image || "/placeholder.svg?height=96&width=96"}
                      alt={item.name}
                      className="w-full h-full object-center object-cover"
                    />
                  </div>

                  <div className="flex-1 ml-0 sm:ml-4 mt-4 sm:mt-0">
                    <h3 className="text-base font-medium">{item.name}</h3>
                    <p className="text-sm text-gray-500">${item.price.toFixed(2)}</p>
                  </div>

                  <div className="flex items-center mt-4 sm:mt-0">
                    <div className="flex items-center border border-gray-300 rounded-md">
                      <button
                        type="button"
                        onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                        disabled={item.quantity <= 1 || updatingItem === item.id}
                        className="p-1 text-gray-500 hover:text-gray-700 disabled:opacity-50"
                      >
                        <Minus className="h-4 w-4" />
                      </button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <button
                        type="button"
                        onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                        disabled={updatingItem === item.id}
                        className="p-1 text-gray-500 hover:text-gray-700 disabled:opacity-50"
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleRemoveItem(item.id)}
                      disabled={deletingItem === item.id}
                      className="ml-4 text-red-500 hover:text-red-700 disabled:opacity-50"
                    >
                      {deletingItem === item.id ? (
                        <div className="h-5 w-5 border-t-2 border-red-500 border-solid rounded-full animate-spin"></div>
                      ) : (
                        <Trash2 className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold mb-4">Order Summary</h2>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal</span>
                <span>${calculateSubtotal().toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Tax (8%)</span>
                <span>${calculateTax().toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Shipping</span>
                <span>{calculateShipping() === 0 ? "Free" : `$${calculateShipping().toFixed(2)}`}</span>
              </div>
              <div className="border-t pt-3 mt-3">
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span>${calculateTotal().toFixed(2)}</span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => router.push("/checkout")}
              className="w-full mt-6 bg-primary hover:bg-primary-dark text-white font-bold py-3 px-4 rounded-md flex items-center justify-center"
            >
              Proceed to Checkout
              <ArrowRight className="ml-2 h-4 w-4" />
            </button>

            <div className="mt-4 text-center">
              <button onClick={() => router.push("/")} className="text-primary hover:text-primary-dark text-sm">
                Continue Shopping
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

