"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { fetchUserProfile, updateUserProfile } from "../../services/api-service"
import { User, Mail, Phone, MapPin, Building, Save } from "lucide-react"
import LoadingSpinner from "../../components/LoadingSpinner"

export default function ProfilePage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState(null)
  const [profile, setProfile] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    company: "",
  })

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const userEmail = localStorage.getItem("userEmail")
        if (!userEmail) {
          router.push("/login")
          return
        }

        setIsLoading(true)
        const data = await fetchUserProfile(userEmail)
        setProfile(data)
      } catch (err) {
        console.error("Failed to fetch profile:", err)
        setError("Failed to load profile. Please try again later.")
      } finally {
        setIsLoading(false)
      }
    }

    loadProfile()
  }, [router])

  const handleUpdateProfile = async (e) => {
    e.preventDefault()
    
    try {
      setIsSaving(true)
      const userEmail = localStorage.getItem("userEmail")
      await updateUserProfile(userEmail, profile)
      setIsEditing(false)
      alert("Profile updated successfully!")
    } catch (error) {
      console.error("Failed to update profile:", error)
      alert("Failed to update profile. Please try again.")
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner />
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center text-red-500 p-4 bg-red-50 rounded-md">{error}</div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold text-gray-900">My Profile</h1>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="text-primary hover:text-primary-dark"
              >
                {isEditing ? "Cancel" : "Edit Profile"}
              </button>
            </div>

            <form onSubmit={handleUpdateProfile} className="space-y-6">
              <div className="flex items-center space-x-4">
                <User className="h-5 w-5 text-gray-400" />
                {isEditing ? (
                  <input
                    type="text"
                    value={profile.name}
                    onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
                    placeholder="Your name"
                  />
                ) : (
                  <span className="text-gray-700">{profile.name}</span>
                )}
              </div>

              <div className="flex items-center space-x-4">
                <Mail className="h-5 w-5 text-gray-400" />
                <span className="text-gray-700">{profile.email}</span>
              </div>

              <div className="flex items-center space-x-4">
                <Phone className="h-5 w-5 text-gray-400" />
                {isEditing ? (
                  <input
                    type="tel"
                    value={profile.phone}
                    onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
                    placeholder="Your phone number"
                  />
                ) : (
                  <span className="text-gray-700">{profile.phone || "No phone number added"}</span>
                )}
              </div>

              <div className="flex items-center space-x-4">
                <MapPin className="h-5 w-5 text-gray-400" />
                {isEditing ? (
                  <textarea
                    value={profile.address}
                    onChange={(e) => setProfile({ ...profile, address: e.target.value })}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
                    placeholder="Your address"
                    rows="2"
                  />
                ) : (
                  <span className="text-gray-700">{profile.address || "No address added"}</span>
                )}
              </div>

              <div className="flex items-center space-x-4">
                <Building className="h-5 w-5 text-gray-400" />
                {isEditing ? (
                  <input
                    type="text"
                    value={profile.company}
                    onChange={(e) => setProfile({ ...profile, company: e.target.value })}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
                    placeholder="Your company"
                  />
                ) : (
                  <span className="text-gray-700">{profile.company || "No company added"}</span>
                )}
              </div>

              {isEditing && (
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="flex items-center bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-md"
                  >
                    {isSaving ? (
                      <div className="h-5 w-5 border-t-2 border-white border-solid rounded-full animate-spin mr-2"></div>
                    ) : (
                      <Save className="h-5 w-5 mr-2" />
                    )}
                    Save Changes
                  </button>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
