export default function Banner({ imageUrl, title, subtitle }) {
  return (
    <div className="relative">
      <div className="w-full h-96 bg-cover bg-center" style={{ backgroundImage: `url(${imageUrl})` }}>
        <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col justify-center items-center text-white p-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-center">{title}</h1>
          <p className="text-xl md:text-2xl text-center max-w-2xl">{subtitle}</p>
          <button className="mt-8 bg-primary hover:bg-primary-dark text-white font-bold py-3 px-6 rounded-full transition duration-300 transform hover:scale-105">
            Shop Now
          </button>
        </div>
      </div>
    </div>
  )
}

