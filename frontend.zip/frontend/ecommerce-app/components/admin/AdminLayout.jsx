"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter, usePathname } from "next/navigation"
import {
  LayoutDashboard,
  Users,
  Package,
  ShoppingCart,
  Mail,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronDown,
  Bell,
} from "lucide-react"
import { logoutUser } from "../../services/api-service"

export default function AdminLayout({ children }) {
  const router = useRouter()
  const pathname = usePathname()
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false)
  const [isProductsSubmenuOpen, setIsProductsSubmenuOpen] = useState(false)

  useEffect(() => {
    // Check if user is admin
    const userRole = localStorage.getItem("userRole")
    if (userRole !== "admin") {
      router.push("/login")
    }

    // Close mobile menu when route changes
    setIsMobileMenuOpen(false)

    // Handle responsive sidebar
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setIsSidebarOpen(false)
      } else {
        setIsSidebarOpen(true)
      }
    }

    // Set initial state
    handleResize()

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [router])

  const handleLogout = async () => {
    try {
      await logoutUser()

      // Clear local storage
      localStorage.removeItem("isLoggedIn")
      localStorage.removeItem("userEmail")
      localStorage.removeItem("userRole")

      // Redirect to login page
      router.push("/login")
    } catch (error) {
      console.error("Logout failed:", error)
    }
  }

  const isActive = (path) => {
    return pathname === path || pathname.startsWith(`${path}/`)
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-0 left-0 z-20 m-4">
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 rounded-md bg-white shadow-md text-gray-600 hover:text-gray-900"
        >
          {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-10 w-64 bg-white shadow-md transform transition-transform duration-300 ease-in-out ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0`}
      >
        <div className="h-full flex flex-col">
          {/* Sidebar header */}
          <div className="h-16 flex items-center justify-center border-b px-4">
            <Link href="/admin/dashboard" className="flex items-center">
              <span className="text-xl font-bold text-primary">ShopSmart Admin</span>
            </Link>
          </div>

          {/* Sidebar content */}
          <div className="flex-1 overflow-y-auto py-4 px-3">
            <ul className="space-y-2">
              <li>
                <Link
                  href="/admin/dashboard"
                  className={`flex items-center p-2 text-base font-normal rounded-lg hover:bg-gray-100 ${
                    isActive("/admin/dashboard") ? "bg-gray-100 text-primary" : "text-gray-900"
                  }`}
                >
                  <LayoutDashboard className="w-6 h-6" />
                  <span className="ml-3">Dashboard</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/admin/users"
                  className={`flex items-center p-2 text-base font-normal rounded-lg hover:bg-gray-100 ${
                    isActive("/admin/users") ? "bg-gray-100 text-primary" : "text-gray-900"
                  }`}
                >
                  <Users className="w-6 h-6" />
                  <span className="ml-3">Users</span>
                </Link>
              </li>
              <li>
                <button
                  type="button"
                  className={`flex items-center p-2 w-full text-base font-normal rounded-lg hover:bg-gray-100 ${
                    isActive("/admin/products") ? "bg-gray-100 text-primary" : "text-gray-900"
                  }`}
                  onClick={() => setIsProductsSubmenuOpen(!isProductsSubmenuOpen)}
                >
                  <Package className="w-6 h-6" />
                  <span className="flex-1 ml-3 text-left whitespace-nowrap">Products</span>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${isProductsSubmenuOpen ? "rotate-180" : ""}`}
                  />
                </button>
                <ul className={`py-2 space-y-2 ${isProductsSubmenuOpen ? "block" : "hidden"}`}>
                  <li>
                    <Link
                      href="/admin/products"
                      className={`flex items-center p-2 pl-11 text-base font-normal rounded-lg hover:bg-gray-100 ${
                        pathname === "/admin/products" ? "text-primary" : "text-gray-900"
                      }`}
                    >
                      All Products
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/admin/products/add"
                      className={`flex items-center p-2 pl-11 text-base font-normal rounded-lg hover:bg-gray-100 ${
                        pathname === "/admin/products/add" ? "text-primary" : "text-gray-900"
                      }`}
                    >
                      Add Product
                    </Link>
                  </li>
                 
                </ul>
              </li>
            
              <li>
                <Link
                  href="/admin/newsletter"
                  className={`flex items-center p-2 text-base font-normal rounded-lg hover:bg-gray-100 ${
                    isActive("/admin/newsletter") ? "bg-gray-100 text-primary" : "text-gray-900"
                  }`}
                >
                  <Mail className="w-6 h-6" />
                  <span className="ml-3">Newsletter</span>
                </Link>
              </li>
             
            </ul>
          </div>

          {/* Sidebar footer */}
          <div className="p-4 border-t">
            <button
              onClick={handleLogout}
              className="flex items-center p-2 w-full text-base font-normal text-red-600 rounded-lg hover:bg-red-50"
            >
              <LogOut className="w-6 h-6" />
              <span className="ml-3">Logout</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile sidebar overlay */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 z-10 bg-gray-900 bg-opacity-50 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        ></div>
      )}

      {/* Mobile sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-20 w-64 bg-white shadow-xl transform transition-transform duration-300 ease-in-out lg:hidden ${
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="h-full flex flex-col">
          <div className="h-16 flex items-center justify-between border-b px-4">
            <Link href="/admin/dashboard" className="flex items-center">
              <span className="text-xl font-bold text-primary">ShopSmart</span>
            </Link>
            <button
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-2 rounded-md text-gray-500 hover:text-gray-900 hover:bg-gray-100"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto py-4 px-3">
            <ul className="space-y-2">
              <li>
                <Link
                  href="/admin/dashboard"
                  className={`flex items-center p-2 text-base font-normal rounded-lg hover:bg-gray-100 ${
                    isActive("/admin/dashboard") ? "bg-gray-100 text-primary" : "text-gray-900"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <LayoutDashboard className="w-6 h-6" />
                  <span className="ml-3">Dashboard</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/admin/users"
                  className={`flex items-center p-2 text-base font-normal rounded-lg hover:bg-gray-100 ${
                    isActive("/admin/users") ? "bg-gray-100 text-primary" : "text-gray-900"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Users className="w-6 h-6" />
                  <span className="ml-3">Users</span>
                </Link>
              </li>
              <li>
                <button
                  type="button"
                  className={`flex items-center p-2 w-full text-base font-normal rounded-lg hover:bg-gray-100 ${
                    isActive("/admin/products") ? "bg-gray-100 text-primary" : "text-gray-900"
                  }`}
                  onClick={() => setIsProductsSubmenuOpen(!isProductsSubmenuOpen)}
                >
                  <Package className="w-6 h-6" />
                  <span className="flex-1 ml-3 text-left whitespace-nowrap">Products</span>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${isProductsSubmenuOpen ? "rotate-180" : ""}`}
                  />
                </button>
                <ul className={`py-2 space-y-2 ${isProductsSubmenuOpen ? "block" : "hidden"}`}>
                  <li>
                    <Link
                      href="/admin/products"
                      className={`flex items-center p-2 pl-11 text-base font-normal rounded-lg hover:bg-gray-100 ${
                        pathname === "/admin/products" ? "text-primary" : "text-gray-900"
                      }`}
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      All Products
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/admin/products/add"
                      className={`flex items-center p-2 pl-11 text-base font-normal rounded-lg hover:bg-gray-100 ${
                        pathname === "/admin/products/add" ? "text-primary" : "text-gray-900"
                      }`}
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      Add Product
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/admin/products/categories"
                      className={`flex items-center p-2 pl-11 text-base font-normal rounded-lg hover:bg-gray-100 ${
                        pathname === "/admin/products/categories" ? "text-primary" : "text-gray-900"
                      }`}
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      Categories
                    </Link>
                  </li>
                </ul>
              </li>
              <li>
                <Link
                  href="/admin/orders"
                  className={`flex items-center p-2 text-base font-normal rounded-lg hover:bg-gray-100 ${
                    isActive("/admin/orders") ? "bg-gray-100 text-primary" : "text-gray-900"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <ShoppingCart className="w-6 h-6" />
                  <span className="ml-3">Orders</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/admin/newsletter"
                  className={`flex items-center p-2 text-base font-normal rounded-lg hover:bg-gray-100 ${
                    isActive("/admin/newsletter") ? "bg-gray-100 text-primary" : "text-gray-900"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Mail className="w-6 h-6" />
                  <span className="ml-3">Newsletter</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/admin/settings"
                  className={`flex items-center p-2 text-base font-normal rounded-lg hover:bg-gray-100 ${
                    isActive("/admin/settings") ? "bg-gray-100 text-primary" : "text-gray-900"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Settings className="w-6 h-6" />
                  <span className="ml-3">Settings</span>
                </Link>
              </li>
            </ul>
          </div>

          <div className="p-4 border-t">
            <button
              onClick={handleLogout}
              className="flex items-center p-2 w-full text-base font-normal text-red-600 rounded-lg hover:bg-red-50"
            >
              <LogOut className="w-6 h-6" />
              <span className="ml-3">Logout</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className={`${isSidebarOpen ? "lg:ml-64" : ""} min-h-screen transition-all duration-300`}>
        {/* Top navbar */}
        <header className="bg-white shadow-sm h-16 fixed top-0 right-0 left-0 z-10 lg:left-64 transition-all duration-300">
          <div className="flex items-center justify-between h-full px-4">
            <div className="flex items-center">
              <button
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="p-2 rounded-md text-gray-500 hover:text-gray-900 hover:bg-gray-100 hidden lg:block"
              >
                <Menu className="h-6 w-6" />
              </button>
            </div>

            <div className="flex items-center space-x-4">
              <button className="p-1 rounded-full text-gray-500 hover:text-gray-900 hover:bg-gray-100 relative">
                <Bell className="h-6 w-6" />
                <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-500"></span>
              </button>

              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-100"
                >
                  <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-700 font-semibold">
                    A
                  </div>
                  <span className="hidden md:block text-sm font-medium">Admin</span>
                  <ChevronDown className="h-4 w-4 text-gray-500" />
                </button>

                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
                    <Link
                      href="/admin/profile"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      onClick={() => setIsUserMenuOpen(false)}
                    >
                      Your Profile
                    </Link>
                    <Link
                      href="/admin/settings"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      onClick={() => setIsUserMenuOpen(false)}
                    >
                      Settings
                    </Link>
                    <button
                      onClick={() => {
                        handleLogout()
                        setIsUserMenuOpen(false)
                      }}
                      className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                    >
                      Logout
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="pt-16 pb-8">{children}</main>
      </div>
    </div>
  )
}

