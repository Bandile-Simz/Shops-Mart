"use client"

import React, { useEffect, useState } from 'react'
import { useNotification } from "../../context/NotificationContext"

export default function AddProductForm({ onAddProduct }) {
  const [categories, setCategories] = useState([])
  const [showOtherCategoryInput, setShowOtherCategoryInput] = useState(false)
  const { showNotification } = useNotification()
  
  const [newProduct, setNewProduct] = useState({
    title: "",
    price: "",
    description: "",
    category: "",
    images: [],
    rating: "",
    count: "",
  })

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch('http://localhost:8080/products/categories')
        const data = await response.json()
        setCategories(data)
      } catch (error) {
        console.error('Error fetching categories:', error)
        showNotification("Failed to load categories", "error")
      }
    }

    fetchCategories()
  }, [showNotification])

  const handleCategoryChange = (e) => {
    const selectedCategory = e.target.value
    if (selectedCategory === 'other') {
      setShowOtherCategoryInput(true)
      setNewProduct({ ...newProduct, category: '' })
    } else {
      setShowOtherCategoryInput(false)
      setNewProduct({ ...newProduct, category: selectedCategory })
    }
  }

  const handleImageChange = (e) => {
    const imageUrls = e.target.value.split(',').map(url => url.trim())
    setNewProduct({ ...newProduct, images: imageUrls })
  }

  const handleAddProduct = async () => {
    try {
      // Validate required fields
      if (!newProduct.title || !newProduct.price || !newProduct.description || !newProduct.category) {
        showNotification("Please fill in all required fields", "error")
        return
      }

      await onAddProduct(newProduct)
      
      // Reset form
      setNewProduct({
        title: "",
        price: "",
        description: "",
        category: "",
        images: [],
        rating: "",
        count: "",
      })
      
      showNotification("Product added successfully", "success")
    } catch (error) {
      console.error('Error adding product:', error)
      showNotification("Failed to add product", "error")
    }
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6">Add New Product</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <input
          type="text"
          placeholder="Product Title *"
          value={newProduct.title}
          onChange={(e) => setNewProduct({ ...newProduct, title: e.target.value })}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
        />
        <input
          type="number"
          placeholder="Price *"
          value={newProduct.price}
          onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
        />
        <textarea
          placeholder="Description *"
          value={newProduct.description}
          onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
          rows="3"
        />
        <div className="space-y-4">
          <select
            value={newProduct.category}
            onChange={handleCategoryChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
          >
            <option value="">Select a category *</option>
            {categories.map((category, index) => (
              <option key={index} value={category}>
                {category}
              </option>
            ))}
            <option value="other">Other</option>
          </select>
          
          {showOtherCategoryInput && (
            <input
              type="text"
              placeholder="Specify a new category *"
              value={newProduct.category}
              onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
            />
          )}
        </div>
        <input
          type="text"
          placeholder="Image URLs (comma separated)"
          value={newProduct.images.join(', ')}
          onChange={handleImageChange}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
        />
        <div className="grid grid-cols-2 gap-4">
          <input
            type="number"
            placeholder="Rating"
            value={newProduct.rating}
            onChange={(e) => setNewProduct({ ...newProduct, rating: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
          />
          <input
            type="number"
            placeholder="Count"
            value={newProduct.count}
            onChange={(e) => setNewProduct({ ...newProduct, count: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
          />
        </div>
      </div>
      <button
        onClick={handleAddProduct}
        className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors duration-200"
      >
        Add Product
      </button>
    </div>
  )
} 