export default function CategoryFilter({ categories, selectedCategory, onCategoryChange }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="text-indigo-900 font-medium">Categories:</span>
      <button
        onClick={() => onCategoryChange("all")}
        className={`px-3 py-1 rounded-full text-sm ${
          selectedCategory === "all" ? "bg-indigo-600 text-white" : "bg-indigo-100 text-indigo-700 hover:bg-indigo-200"
        }`}
      >
        All
      </button>

      {categories.map((category) => (
        <button
          key={category}
          onClick={() => onCategoryChange(category)}
          className={`px-3 py-1 rounded-full text-sm ${
            selectedCategory === category
              ? "bg-indigo-600 text-white"
              : "bg-indigo-100 text-indigo-700 hover:bg-indigo-200"
          }`}
        >
          {category}
        </button>
      ))}
    </div>
  )
}

