"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { useRouter, usePathname } from "next/navigation"
import { logoutUser, fetchAllCartItems, subscribeToCart } from "../services/api-service"
import { Menu, X, ShoppingCart, Heart, User, LogOut } from "lucide-react"

export default function Header() {
  const router = useRouter()
  const pathname = usePathname()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [userRole, setUserRole] = useState(null)
  const [isScrolled, setIsScrolled] = useState(false)
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const dropdownRef = useRef(null)
  const [cartCount, setCartCount] = useState(0)

  useEffect(() => {
    // Check if user is logged in
    const loggedIn = localStorage.getItem("isLoggedIn") === "true"
    const role = localStorage.getItem("userRole")

    setIsLoggedIn(loggedIn)
    setUserRole(role)

    // Add scroll event listener
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  useEffect(() => {
    const loadCartCount = async () => {
      try {
        const items = await fetchAllCartItems()
        setCartCount(items.length)
      } catch (error) {
        console.error("Failed to fetch cart count:", error)
      }
    }

    // Initial load
    loadCartCount()

    // Subscribe to cart changes
    const unsubscribe = subscribeToCart(loadCartCount)

    return () => {
      unsubscribe()
    }
  }, [])

  const handleLogout = async () => {
    try {
      await logoutUser()

      // Clear local storage
      localStorage.removeItem("isLoggedIn")
      localStorage.removeItem("userEmail")
      localStorage.removeItem("userRole")

      setIsLoggedIn(false)
      setUserRole(null)

      // Redirect to home page
      router.push("/")
    } catch (error) {
      console.error("Logout failed:", error)
    }
  }

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-indigo-900 shadow-md" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <span className="text-xl font-bold text-white">ShopSmart</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link
              href="/"
              className={`text-sm font-medium hover:text-indigo-200 ${
                pathname === "/" ? "text-indigo-200" : "text-white"
              }`}
            >
              Home
            </Link>
            <Link
              href="/products"
              className={`text-sm font-medium hover:text-indigo-200 ${
                pathname === "/products" ? "text-indigo-200" : "text-white"
              }`}
            >
              Products
            </Link>
          </nav>

          {/* Cart and User Actions */}
          <div className="flex items-center space-x-4">
            {/* Cart */}
            <Link href="/cart" className="relative p-1 text-white hover:text-indigo-200">
              <ShoppingCart className="h-6 w-6" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-indigo-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>

            {/* Wishlist */}
            <Link href="/wishlist" className="relative p-1 text-white hover:text-indigo-200">
              <Heart className="h-6 w-6" />
            </Link>

            {/* User Account */}
            {isLoggedIn ? (
              <div className="relative" ref={dropdownRef}>
                <button 
                  className="p-1 text-white hover:text-indigo-200"
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                >
                  <User className="h-6 w-6" />
                </button>
                {isDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
                    <div className="px-4 py-2 text-sm text-gray-700 border-b">
                      {userRole === "admin" ? "Admin Account" : "My Account"}
                    </div>

                    {userRole === "admin" && (
                      <Link 
                        href="/admin/dashboard" 
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-50"
                        onClick={() => setIsDropdownOpen(false)}
                      >
                        Admin Dashboard
                      </Link>
                    )}

                    <Link 
                      href="/profile" 
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-50"
                      onClick={() => setIsDropdownOpen(false)}
                    >
                      Profile
                    </Link>
                    <Link 
                      href="/orders" 
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-50"
                      onClick={() => setIsDropdownOpen(false)}
                    >
                      Orders
                    </Link>
                    <button
                      onClick={() => {
                        handleLogout()
                        setIsDropdownOpen(false)
                      }}
                      className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-indigo-50"
                    >
                      <div className="flex items-center">
                        <LogOut className="h-4 w-4 mr-2" />
                        Logout
                      </div>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link href="/login" className="p-1 text-white hover:text-indigo-200">
                <User className="h-6 w-6" />
              </Link>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-1 text-white hover:text-indigo-200"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-indigo-800">
            <nav className="flex flex-col space-y-4">
              <Link
                href="/"
                className={`text-sm font-medium hover:text-indigo-200 ${
                  pathname === "/" ? "text-indigo-200" : "text-white"
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                href="/products"
                className={`text-sm font-medium hover:text-indigo-200 ${
                  pathname === "/products" ? "text-indigo-200" : "text-white"
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                Products
              </Link>

              {isLoggedIn ? (
                <>
                  {userRole === "admin" && (
                    <Link
                      href="/admin/dashboard"
                      className="text-sm font-medium text-white hover:text-indigo-200"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Admin Dashboard
                    </Link>
                  )}
                  <Link
                    href="/profile"
                    className="text-sm font-medium text-white hover:text-indigo-200"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Profile
                  </Link>
                  <Link
                    href="/orders"
                    className="text-sm font-medium text-white hover:text-indigo-200"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Orders
                  </Link>
                  <button
                    onClick={() => {
                      handleLogout()
                      setIsMenuOpen(false)
                    }}
                    className="text-sm font-medium text-red-400 hover:text-red-300 text-left"
                  >
                    <div className="flex items-center">
                      <LogOut className="h-4 w-4 mr-2" />
                      Logout
                    </div>
                  </button>
                </>
              ) : (
                <Link
                  href="/login"
                  className="text-sm font-medium text-white hover:text-indigo-200"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Sign In / Register
                </Link>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}

