"use client"
import { useRouter } from "next/navigation"
import { addCartItem, addToWishlist } from "../services/api-service"
import { Heart, ShoppingCart } from "lucide-react"

export default function ProductCard({ product }) {
  const router = useRouter()
  const { id, name, price, image, description, rating } = product

  const handleAddToCart = async (e) => {
    e.stopPropagation()
    try {
      await addCartItem({
        productId: id,
        quantity: 1,
        price,
        name: name,
        image: product.images?.[0] || product.image,
        description: description
      })
      // Show success notification
      alert("Product added to cart!")
    } catch (error) {
      console.error("Failed to add to cart:", error)
      alert("Failed to add to cart. Please try again.")
    }
  }

  const handleAddToWishlist = async (e) => {
    e.stopPropagation()
    try {
      // Assuming we have the user's email from authentication
      const userEmail = localStorage.getItem("userEmail")
      if (!userEmail) {
        router.push("/login")
        return
      }

      await addToWishlist(userEmail, { productId: id })
      // Show success notification
      alert("Product added to wishlist!")
    } catch (error) {
      console.error("Failed to add to wishlist:", error)
      alert("Failed to add to wishlist. Please try again.")
    }
  }

  const navigateToProductDetail = () => {
    router.push(`/products/${id}`)
  }

  // Generate star rating display
  const renderRating = () => {
    const stars = []
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <span key={i} className={i <= rating ? "text-yellow-400" : "text-gray-300"}>
          ★
        </span>,
      )
    }
    return stars
  }

  return (
    <div
      className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-xl hover:scale-105 cursor-pointer"
      onClick={navigateToProductDetail}
    >
      <div className="relative h-48 overflow-hidden">
        <img
          src={product.images?.[0] || product.image || "/placeholder.svg?height=192&width=100%"}
          alt={name}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2 flex space-x-2">
          <button
            onClick={handleAddToWishlist}
            className="p-2 bg-white rounded-full shadow hover:bg-indigo-50"
            aria-label="Add to wishlist"
          >
            <Heart className="h-5 w-5 text-indigo-600" />
          </button>
        </div>
      </div>

      <div className="p-4">
        <h3 className="text-lg font-semibold mb-1 line-clamp-1 text-indigo-900">{name}</h3>
        <div className="flex mb-2">{renderRating()}</div>
        <p className="text-indigo-700 text-sm mb-3 line-clamp-2">{description}</p>

        <div className="flex justify-between items-center">
          <span className="text-lg font-bold text-indigo-900">${price.toFixed(2)}</span>
          <button
            onClick={handleAddToCart}
            className="flex items-center bg-indigo-600 text-white px-3 py-2 rounded-md hover:bg-indigo-700 transition-colors"
          >
            <ShoppingCart className="h-4 w-4 mr-1" />
            Add
          </button>
        </div>
      </div>
    </div>
  )
}

