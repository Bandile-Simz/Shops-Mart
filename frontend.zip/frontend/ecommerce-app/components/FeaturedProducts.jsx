"use client"
import { useRouter } from "next/navigation"
import { useMemo } from "react"

export default function FeaturedProducts({ products }) {
  const router = useRouter()

  // Randomly select 4 products
  const randomProducts = useMemo(() => {
    if (!products || products.length === 0) return []
    
    const shuffled = [...products].sort(() => Math.random() - 0.5)
    return shuffled.slice(0, 4)
  }, [products])

  if (!products || products.length === 0) {
    return null
  }

  return (
    <div className="my-8">
      <h2 className="text-2xl font-bold mb-6">Featured Products</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {randomProducts.map((product) => (
          <div
            key={product.id}
            className="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer"
            onClick={() => router.push(`/products/${product.id}`)}
          >
            <div className="aspect-w-1 aspect-h-1">
              <img
                src={product.images?.[0] || product.image || "/placeholder.svg?height=300&width=300"}
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
              <h3 className="text-white font-bold text-lg">{product.name}</h3>
              <p className="text-white/90 text-sm mb-2">{product.description.substring(0, 60)}...</p>
              <span className="text-white font-bold">${product.price.toFixed(2)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

