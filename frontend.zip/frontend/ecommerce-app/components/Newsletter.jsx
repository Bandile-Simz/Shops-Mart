"use client"

import { useState } from "react"
import { Mail } from "lucide-react"

export default function Newsletter() {
  const [email, setEmail] = useState("")
  const [subscribed, setSubscribed] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = (e) => {
    e.preventDefault()

    if (!email.trim()) {
      setError("Please enter your email address")
      return
    }

    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setError("Please enter a valid email address")
      return
    }

    // Here you would typically call an API to subscribe the user
    // For now, we'll just simulate success
    setSubscribed(true)
    setError("")
  }

  return (
    <div className="bg-gray-100 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto text-center">
          <Mail className="h-12 w-12 mx-auto mb-4 text-primary" />
          <h2 className="text-3xl font-bold mb-4">Subscribe to our Newsletter</h2>
          <p className="text-gray-600 mb-6">
            Stay updated with our latest products, exclusive offers, and shopping tips.
          </p>

          {subscribed ? (
            <div className="bg-green-100 text-green-700 p-4 rounded-md">
              Thank you for subscribing! We've sent a confirmation email to your inbox.
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2">
              <div className="flex-grow">
                <input
                  type="email"
                  placeholder="Your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 rounded-md border focus:outline-none focus:ring-2 focus:ring-primary"
                />
                {error && <p className="text-red-500 text-sm mt-1 text-left">{error}</p>}
              </div>
              <button
                type="submit"
                className="bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-md transition duration-300"
              >
                Subscribe
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}

